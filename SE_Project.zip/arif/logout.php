<?php
session_start();
session_unset();
session_destroy();
header("Location: signup.php"); // Redirect to login page or homepage
exit();
?>
