<?php
session_start();
include "db.php";

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

$email = $_SESSION['email'];

if (isset($_FILES['profile_photo'])) {
    $fileName = $_FILES['profile_photo']['name'];
    $tempName = $_FILES['profile_photo']['tmp_name'];
    $uploadDir = "uploads/"; // এই ফোল্ডার বানাও তোমার প্রজেক্টে

    $filePath = $uploadDir . uniqid() . "_" . $fileName;
    move_uploaded_file($tempName, $filePath);

    $stmt = $conn->prepare("UPDATE users SET profile_photo = ? WHERE email = ?");
    $stmt->bind_param("ss", $filePath, $email);
    $stmt->execute();
    $stmt->close();

    // Session এ ছবির পাথ সেভ করে দাও
    $_SESSION['profile_photo'] = $filePath;

    header("Location: profile.php");
    exit();
}
?>
