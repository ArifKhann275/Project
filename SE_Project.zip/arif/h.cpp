#include <iostream>
#include <cstdlib> // for system()
using namespace std;

int main() {
    int time;

    // Ask user for delay time in seconds
    cout << "Enter the delay time in seconds before shutdown: ";
    cin >> time;

    // Build the shutdown command
    string command = "shutdown /s /t " + to_string(time);

    // Execute the command
    system(command.c_str());

    cout << "System will shut down in " << time << " seconds..." << endl;
    return 0;

}