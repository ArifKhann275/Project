<?php
session_start();

// যদি ইউজার লগইন না করে তাহলে ব্যাক করে দাও
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}
?>

<h2>Welcome to Your Dashboard!</h2>
<p>Hello, <?php echo $_SESSION['email']; ?> 👋</p>

<a href="logout.php">Logout</a>
