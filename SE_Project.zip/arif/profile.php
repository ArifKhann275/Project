<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            background-color: #383a3b;
        }

        .image-container {


            position: relative;
            width: 100%;
            
            margin: auto;
        }

        .image-container img{
            width: 100%;
            height: 200px;
            display: block;
            object-fit: cover;
        }

        .center-text {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
            font-size: 36px;
            font-weight: bold;
            text-shadow: 2px 2px 6px rgba(0, 0, 0, 0.7);
        }

        .breadcrumb {
            margin-top: 10px;
            color: #032917;
        }

        .profile {
            display: flex;
            align-items: center;
            padding: 20px;
            background-color: #2c2f30;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
        }

        .profile img {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            object-fit: cover;
        }

        .profile-details {
            margin-left: 15px;
        }

        .profile-details h3 {
            font-size: 18px;
            color: white;
            font-weight: bold;
        }

        .stars {
            color: gold;
        }

        .main {
            display: flex;
        }

        .sidebar {
    width: 250px;
    background-color: #0074cc; /* Blue */
    padding: 20px 15px;
    border-radius: 10px;
}

.menu {
    list-style: none;
    padding: 0;
    margin: 0;
}

.menu li {
    color: #ffffff;
    padding: 12px 10px;
    cursor: pointer;
    font-size: 16px;
    border-radius: 8px;
    transition: all 0.3s ease;
}
.menu a {
    color: #ffffff;
    padding: 12px 10px;
    cursor: pointer;
    font-size: 16px;
    border-radius: 8px;
    transition: all 0.3s ease;
}
.menu a:hover{
    background-color: #005fa3;
}

.menu li:hover {
    background-color: #005fa3;
}

.menu li.active {
    background-color: #004080;
    color: #ffeb3b; /* Yellow color on active */
}


        .content {
            flex: 1;
            padding: 20px;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }

        .card {
            background-color: #2c2f30;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .card h2 {
            font-size: 24px;
            color: rgb(254, 255, 255);
        }

        .card p {
            margin-top: 10px;
            color: #ffffff;
        }

        .section-title {
            margin-top: 30px;
            font-size: 20px;
            font-weight: 600;
        }

        .my-courses {
            display: none;
            margin-top: 30px;
        }

        .course-boxes {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .course-card {
            background-color: #2c2f30;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        }

        .course-card img {
            width: 100%;
            height: 160px;
            object-fit: cover;
        }

        .course-content {
            padding: 15px;
        }

        .course-content h4 {
            color: rgb(255, 255, 255);
            font-size: 16px;
            margin-bottom: 5px;
        }

        .course-meta {
            font-size: 14px;
            color: rgb(167, 248, 221);
        }

        .course-button {
        margin-top: 10px;
        text-align: center;
        }

        .course-content a{
        padding: 8px 16px;
        background-color: #22e26c;
        margin-left: 195px;
        margin-left: 160px;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-weight: bold;
        
        transition: background-color 0.4s;
        }

        .course-content a:hover {
            background-color: #0c7cd5;
        }

    </style>
</head>
<body>
    <div class="image-container">
        <img src="cover1.png" alt="valona">
        <div class="center-text">Dashboard</div>
    </div>

    <div class="profile">
        <img src="r2.png" alt="Profile Picture">
        <div class="profile-details">
            <h3>Tabassum Soha</h3>
            <div class="stars">★★★★★</div>
        </div>
    </div>
    <form action="upload_photo.php" method="POST" enctype="multipart/form-data">
        <input type="file" name="profile_photo" required>
        <button type="submit">Upload Photo</button>
    </form>
    

    <div class="main">
        <div class="sidebar">
            <ul class="menu">
                <li onclick="showSection('dashboard')">Dashboard</li>
                <li onclick="showSection('myCourses')">My Courses</li>
                <li onclick="handleClick('profile')">My Profile</li>
                <li onclick="handleClick('reviews')">Reviews</li>
                <li onclick="handleClick('quiz')">My Quiz Attempts</li>
                <li onclick="handleClick('qa')">Question & Answer</li>
                <a href="logout.php">Logout</a>

                
            </ul>
        </div>
        

        <div class="content">
            <div id="dashboard" class="dashboard-section">
                <div class="cards">
                    <div class="card">
                        <h2>2</h2>
                        <p>Enrolled Courses</p>
                    </div>
                    <div class="card">
                        <h2>2</h2>
                        <p>Active Courses</p>
                    </div>
                    <div class="card">
                        <h2>0</h2>
                        <p>Completed Courses</p>
                    </div>
                    <div class="card">
                        <h2>5</h2>
                        <p>Total Students</p>
                    </div>
                    <div class="card">
                        <h2>62</h2>
                        <p>Total Courses</p>
                    </div>
                    <div class="card">
                        <h2>$0.00</h2>
                        <p>Total Earnings</p>
                    </div>
                </div>

                <div class="section-title">In Progress Courses</div>
            </div>

            <div id="myCourses" class="my-courses">
                <div class="section-title">My Courses</div>
                <div class="course-boxes">

                    <div class="course-card">
                        <img src="course 5.png" alt="Course">
                        <div class="course-content">
                            <small>February 15, 2025 2:30 pm</small>
                            <h4>Create Your Online Brand As A Fitness Trainer</h4>
                            <div class="course-meta">
                                ⏱️ 30h 10m &nbsp;&nbsp;👥 19 <br><br> Free  <a href="signup.php#courses">Let's Learn</a> 
                            </div>
                            <div class="course-button">
                                
                            </div>
                        </div>
                    </div>

                    <div class="course-card">
                        <img src="course 2.png" alt="Course">
                        <div class="course-content">
                            <small>February 15, 2025 2:30 pm</small>
                            <h4>Create Your Online Brand As A Fitness Trainer</h4>
                            <div class="course-meta">
                                ⏱️ 30h 10m &nbsp;&nbsp;👥 19 <br><br> Free <a href="signup.php#courses">Let's Learn</a>
                            </div>
                            <div class="course-button">
                                
                            </div>
                        </div>
                    </div>
                    

                    <div class="course-card">
                        <img src="course6.png" alt="Course">
                        <div class="course-content">
                            <small>February 15, 2025 2:30 pm</small>
                            <h4>Create Your Online Brand As A Fitness Trainer</h4>
                            <div class="course-meta">
                                ⏱️ 30h 10m &nbsp;&nbsp;👥 19 <br><br> Free <a href="course1.html">Let's Learn</a>
                            </div>
                            <div class="course-button">
                                
                            </div>
                        </div>
                    </div>

                    <div class="course-card">
                        <img src="course 4.png" alt="Course">
                        <div class="course-content">
                            <small>February 15, 2025 2:30 pm</small>
                            <h4>Create Your Online Brand As A Fitness Trainer</h4>
                            <div class="course-meta">
                                ⏱️ 30h 10m &nbsp;&nbsp;👥 19 <br><br> Free <a href="signup.php#courses">Let's Learn</a>
                            </div>
                            <div class="course-button">
                                
                            </div>
                        </div>
                    </div>

                    <div class="course-card">
                        <img src="course 5.png" alt="Course">
                        <div class="course-content">
                            <small>February 15, 2025 2:30 pm</small>
                            <h4>Create Your Online Brand As A Fitness Trainer</h4>
                            <div class="course-meta">
                                ⏱️ 30h 10m &nbsp;&nbsp;👥 19 <br><br> Free <a href="signup.php#courses">Let's Learn</a>
                            </div>
                            <div class="course-button">
                                
                            </div>
                        </div>
                    </div>



                </div>
            </div>

        </div>
    </div>

    <script>
        function showSection(id) {
            document.getElementById('dashboard').style.display = id === 'dashboard' ? 'block' : 'none';
            document.getElementById('myCourses').style.display = id === 'myCourses' ? 'block' : 'none';
        }
    </script>
</body>
</html>