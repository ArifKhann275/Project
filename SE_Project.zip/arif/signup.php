<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "arif";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
include "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // ⬅️ এখানে password এর সাথে profile_photo ও নিচ্ছি
    $stmt = $conn->prepare("SELECT password, profile_photo FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($hashedPassword, $profilePhoto);

    if ($stmt->fetch()) {
        if (password_verify($password, $hashedPassword)) {
            $_SESSION['email'] = $email;
            $_SESSION['profile_photo'] = $profilePhoto; // ✅ এখানে প্রোফাইল ছবি সেভ হচ্ছে সেশনে

            header("Location: profile.php");
            exit();
        } else {
            echo "Invalid password!";
        }
    } else {
        echo "User not found!";
    }

    $stmt->close();
}

error_reporting(E_ALL);
ini_set('display_errors', 1);
include "db.php";
$success_message = ""; // Default to an empty string

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $username, $email, $password);

    if ($stmt->execute()) {
        $success_message = "Signup successful!"; // Set the success message
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responsive Navbar</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="valo.css">
   


    <style>
        body {
            font-family: Arial, sans-serif;
            transition: background 0.3s, color 0.3s;
        }
        .dark-theme {
            background: #383a3b;
            color: white;
            .box{
                background: #2c2f30;

            }
            
            .courses .swiper-slide{
                background: #2c2f30;
            }
            .review-card{
                background: #2c2f30;
            }
            .teachers .swiper-slide{
                background: transparent;
            }
            .container .contactform::after{
                background: #2c2f30;
            }
            .navbar{
                background-color: #2c2f30;
            }
            
        }
        .light-theme {
            background: #032917;
            color: #ffffff;
            .box{
                background: #0f492c; 
            }
            .courses .swiper-slide{
                background: #0f492c;

            }
            
            .review-card{
                background: #0f492c;
            }
            .teachers .swiper-slide{
                background: transparent;
            }
            .container .contactform::after{
                background: #0f492c;
            }
            .navbar{
                background-color: #0f492c;
            }
        }
        
    </style>


</head>
<body class="homepage">
    <div class="navbar">
        <div class="logo"> <b>SkillHub</b></div>
        <button class="menu-button" onclick="toggleMenu()">&#9776;</button>
        <div class="menu" id="menu">
            <a href="#">Home</a>
            <a href="#courses">Courses</a>
            <a href="#teachers">Teachers</a>
            <a href="#reviews">Reviews</a>
            <button class="toggle-btn" onclick="toggleTheme()">🌙</button>
            <?php 
            

            if (isset($_SESSION['email'])): ?>
            <a href="profile.php" style="white-space: nowrap; font-size: 20px;">
            <?php if (isset($_SESSION['profile_photo']) && !empty($_SESSION['profile_photo'])): ?>
            <img src="<?php echo $_SESSION['profile_photo']; ?>" 
                alt="Profile" 
                style="width: 37px; height: 34px; border-radius: 50%; vertical-align: middle; object-fit: cover; margin-top:-10px">

            <?php else: ?>
            <i style="font-size: 23px;">👤</i>
            <?php endif; ?>
        </a>
        <?php else: ?>
        <a href="#" id="openModal" style="white-space: nowrap;">Sign in</a>
        <?php endif; ?>
                

            
            

            
            
            
        </div>
    </div>


    <?php if ($success_message): ?>
        <div class="success-message"><?php echo $success_message; ?></div>
    <?php endif; ?>



    <div class="modal" id="authModal">
        <div class="modal-content">
          <span class="close-btn" id="closeModal">&times;</span>
    
           <!-- Sign In Form -->
           <div class="form active" id="signInForm">
          <h2>Login</h2>
            <form method="POST" action="">
            Email: <input type="email" name="email" required><br><br>
            Password: <input type="password" name="password" required><br><br>
            <button type="submit">Login</button>
            </form>
            <div class="switch-link">
              Not registered yet? <a id="showSignUp">Sign up</a>
            </div>
          </div>
           
    
          <!-- Sign Up Form -->
          <div class="signup-container">
            <h2>Create an Account</h2>
            <form method="POST" action="">
                <input type="text" name="username" placeholder="Username" required><br><br>
                <input type="email" name="email" placeholder="Email" required><br><br>
                <input type="password" name="password" placeholder="Password" required><br><br>
                <button type="submit">Sign Up</button>
            </form>
           </div>


          

        </div>
      </div>



    <script>
        const modal = document.getElementById("authModal");
        const openModal = document.getElementById("openModal");
        const closeModal = document.getElementById("closeModal");
    
        const signInForm = document.getElementById("signInForm");
        const signUpForm = document.getElementById("signUpForm");
    
        const showSignUp = document.getElementById("showSignUp");
        const showSignIn = document.getElementById("showSignIn");
    
        openModal.onclick = () => {
          modal.style.display = "flex";
          signInForm.classList.add("active");
          signUpForm.classList.remove("active");
        };
    
        closeModal.onclick = () => {
          modal.style.display = "none";
        };
    
        showSignUp.onclick = () => {
          signInForm.classList.remove("active");
          signUpForm.classList.add("active");
        };
    
        showSignIn.onclick = () => {
          signUpForm.classList.remove("active");
          signInForm.classList.add("active");
        };
    
        // Optional: Close modal when clicking outside
        window.onclick = (e) => {
          if (e.target === modal) {
            modal.style.display = "none";
          }
        };
      </script>
    
    
    

    

    
    
    <section class="home" id="home">
        <div class="row">
            <div class="content">
                
                <h1><span style="color: white;">Online</span><br> <span style="color: #00E77F;">Education</span></h1>
                
            </div>
            <div class="image">
                <img src="untitile.png" alt="">
            </div>
        </div>
    </section>
    
    <section class="count">
        <div class="box">
            <i class="fas fa-graduation-cap"></i>
            <div class="content">
                <h3 data-target="150">0</h3>
                <p>courses</p>
            </div>
        </div>
    
        <div class="box">
            <i class="fas fa-user-graduate"></i>
            <div class="content">
                <h3 data-target="1500">0</h3>
                <p>students</p>
            </div>
        </div>
    
        <div class="box">
            <i class="fas fa-chalkboard-user"></i>
            <div class="content">
                <h3 data-target="80">0</h3>
                <p>teachers</p>
            </div>
        </div>
    
        <div class="box">
            <i class="fas fa-face-smile"></i>
            <div class="content">
                <h3 data-target="97">0 </h3>
                <p>satisfaction</p>
            </div>
        </div>
    </section>
    <script src="script.js"></script>

    <section class="courses" id="courses">
        <h1 class="heading">Our <span>courses</span></h1>

        <div class="swiper-container">
            
            <div class="swiper-wrapper">
            <div class="swiper-slide">
                    <img src="course 1.png" alt="Course Image" class="course-image">
                    <div class="course-content">
                    <h2 class="course-title">HTML</h2>
                    
                    <div class="course-review">
                        <span class="stars">★★★★★</span>
                        <span class="review-text">( 99 Review )</span>
                        <div class="left">
                            <i class="icon" style="font-size: 21px;">👥</i>
                            <span style="margin-left: 5px; color: #ffffff; font-weight: bold; margin-top: 9px;">245</span>
                          </div>
                    </div>
                    <div class="course-footer">
                        <span class="price">Free*</span>
                        
                        <a href="course1.html" class="enroll-button">Take the Courses</a>
                        
                    </div>
                    </div>
                      
                      
                    
                </div>

                <div class="swiper-slide">
                    <img src="course 2.png" alt="Course Image" class="course-image">
                    <div class="course-content">
                    <h2 class="course-title">JavaScript</h2>
                    
                    <div class="course-review">
                        <span class="stars">★★★★★</span>
                        <span class="review-text">( 97 Review )</span>
                        <div class="left">
                            <i class="icon" style="font-size: 21px;">👥</i>
                            <span style="margin-left: 5px; color: #ffffff; font-weight: bold; margin-top: 9px;">187</span>
                          </div>
                    </div>
                    <div class="course-footer">
                        <span class="price">Free*</span>
                        
                        <a href="course2.html" class="enroll-button">Take the Courses</a>
                        
                    </div>
                    </div>
                      
                      
                    
                </div>

                <div class="swiper-slide">
                    <img src="course6.png" alt="Course Image" class="course-image">
                    <div class="course-content">
                    <h2 class="course-title">NoteJS</h2>
                    
                    <div class="course-review">
                        <span class="stars">★★★★★</span>
                        <span class="review-text">( 48 Review )</span>
                        <div class="left">
                            <i class="icon" style="font-size: 21px;">👥</i>
                            <span style="margin-left: 5px; color: #ffffff; font-weight: bold; margin-top: 9px;">159</span>
                          </div>
                    </div>
                    <div class="course-footer">
                        <span class="price">Free*</span>
                        
                        <a href="course3.html" class="enroll-button">Take the Courses</a>
                        
                    </div>
                    </div>
                      
                      
                    
                </div>

                <div class="swiper-slide">
                    <img src="course 4.png" alt="Course Image" class="course-image">
                    <div class="course-content">
                    <h2 class="course-title">BootStrap</h2>
                    
                    <div class="course-review">
                        <span class="stars">★★★★★</span>
                        <span class="review-text">( 53 Review )</span>
                        <div class="left">
                            <i class="icon" style="font-size: 21px;">👥</i>
                            <span style="margin-left: 5px; color: #ffffff; font-weight: bold; margin-top: 9px;">94</span>
                          </div>
                    </div>
                    <div class="course-footer">
                        <span class="price">Free*</span>
                        
                        <a href="course4.html" class="enroll-button">Take the Courses</a>
                        
                    </div>
                    </div>
                      
                      
                    
                </div>

                <div class="swiper-slide">
                    <img src="course 5.png" alt="Course Image" class="course-image">
                    <div class="course-content">
                    <h2 class="course-title">SQL</h2>
                    
                    <div class="course-review">
                        <span class="stars">★★★★★</span>
                        <span class="review-text">( 69 Review )</span>
                        <div class="left">
                            <i class="icon" style="font-size: 21px;">👥</i>
                            <span style="margin-left: 5px; color: #ffffff; font-weight: bold; margin-top: 9px;">162</span>
                          </div>
                    </div>
                    <div class="course-footer">
                        <span class="price">Free*</span>
                        
                        <a href="course5.html" class="enroll-button">Take the Courses</a>
                        
                    </div>
                    </div>
                    
                </div>


                <div class="swiper-pagination"></div>
                

            </div>
            <div class="swiper-pagination"></div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
    </section>


    <sections class="teachers" id="teachers">
        <h2 class="heading">Expert <span>tutors</span></h2><br>
        <div class="swiper-container1">
            
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <img src="Teacher 1.jpeg" alt="">
                    <h3>Albert Einstein</h3>
                    <div class="share">
                        <a href="#" class="fab fa-facebook-f"></a>
                        <a href="#" class="fab fa-twitter"></a>
                    </div>
                </div>

                <div class="swiper-slide">
                    <img src="Teacher 2.jpeg" alt="">
                    <h3>Nikola Tesla</h3>
                    <div class="share">
                        <a href="#" class="fab fa-facebook-f"></a>
                        <a href="#" class="fab fa-twitter"></a>
                    </div>
                </div>

                <div class="swiper-slide">
                    <img src="Teacher 3.jpeg" alt="">
                    <h3>Isaac Newton</h3>
                    <div class="share">
                        <a href="#" class="fab fa-facebook-f"></a>
                        <a href="#" class="fab fa-twitter"></a>
                    </div>
                    
                </div>

                <div class="swiper-slide">
                    <img src="Teacher 4.jpeg" alt="">
                    <h3>Marie Curie</h3>
                    <div class="share">
                        <a href="#" class="fab fa-facebook-f"></a>
                        <a href="#" class="fab fa-twitter"></a>
                    </div>
                </div>

                <div class="swiper-slide">
                    <img src="Teacher 5.jpeg" alt="">
                    <h3>Natasha Stott Despoja</h3>
                    <div class="share">
                        <a href="#" class="fab fa-facebook-f"></a>
                        <a href="#" class="fab fa-whatsapp"></a>
                    </div>
                </div>
                <div class="swiper-pagination"></div>
                

            </div>
            <div class="swiper-pagination"></div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
    </sections>

    <script>
        var swiper = new Swiper(".swiper-container", {
        slidesPerView: 3.2, // Show part of the previous and next slides
        spaceBetween: 30,  // Space between slides
        centeredSlides: true, // Center the active slide
        loop: true, // Infinite looping
        
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
    });
    
      </script>


    
<script>
    var swiper = new Swiper(".swiper-container1", {
    slidesPerView: 3.3, // Show part of the previous and next slides
    spaceBetween: 90,  // Space between slides
    centeredSlides: true, // Center the active slide
    loop: true, // Infinite looping
    
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
});

  </script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

  




<h2 class="heading">Student's <span>reviews</span></h2>
<div class="swiper-container2" id="reviews">
    
    <div class="swiper-wrapper">
        
        <!-- Review Card 1 -->
        
        <div class="swiper-slide review-card">
            <p class="review-text">
            The teachers are more beautiful than the courses. 
            I am completely satisfied <br>
                
            </p>
            <div class="review-footer">
                <img src="r11.png" class="profile-pic">
                <div>
                    <p class="name">Dipok Sorkar</p>
                    <div class="stars">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Review Card 2 -->
        <div class="swiper-slide review-card">
            <p class="review-text">
                Numquam Consequatur Velit Autem <br>
                Distinctio Possimus Culpa!
            </p>
            <div class="review-footer">
                <img src="r2.png" class="profile-pic">
                <div>
                    <p class="name">Tabassum Soha</p>
                    <div class="stars">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-alt"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Review Card 3 -->
        <div class="swiper-slide review-card">
            <p class="review-text">
                Consectetur Adipisicing Elit. Illum <br>
                Necessitatibus Atque Fuga Delectus.
            </p>
            <div class="review-footer">
                <img src="r3.png" class="profile-pic">
                <div>
                    <p class="name">Hero Alam</p>
                    <div class="stars">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        
                    </div>
                </div>
            </div>
        </div>

        <div class="swiper-slide review-card">
            <p class="review-text">
                Consectetur Adipisicing Elit. Illum <br>
                Necessitatibus Atque Fuga Delectus.
            </p>
            <div class="review-footer">
                <img src="r4.jpeg" class="profile-pic">
                <div>
                    <p class="name">Jannat</p>
                    <div class="stars">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-alt"></i>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Swiper Navigation Buttons -->
    

    <!-- Swiper Pagination -->
    <div class="swiper-pagination"></div>
</div>
</div>

<section class="contact">
    <div class="content">
        <h2 class="heading"> <span>Contact</span> us</h2>

        
    </div>
    <div class="container">
        <div class="contactinfo">
            
                <div class="box2">
                    <div class="icon2"><b></b><i class="fa-solid fa-house fa-sm"></i></div>
                    <div class="text2">
                        <h3>Address</h3>
                        <p> Holding 77 Beribadh Road, Dhaka</p>
                    </div>
                </div>

                <div class="box2">
                    <div class="icon2"><b></b><i class="fa-solid fa-phone fa-sm"></i></div>
                    <div class="text2">
                        <h3>Phone</h3>
                        <p> 01987654321</p>
                    </div>
                </div>

                <div class="box2">
                    <div class="icon2"><b></b><i class="fa-solid fa-envelope fa-sm"></i></div>
                    <div class="text2">
                        <h3>Email</h3>
                        <p>thisisdusto@gmail.com</p>
                    </div>
                </div>

                <h2 class="txt">Connect with us</h2>
                <ul class="sci">
                    <li><a href="#"><i class="fa-brands fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa-brands fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa-brands fa-instagram"></i></a></li>
                    <li><a href="#"><i class="fa-brands fa-youtube"></i></a></li>
                </ul>

            
        </div>
        <div class="contactform">
            <form>
                <h2>Send Message</h2>
                <div class="inputbox">
                    <input type="text" name="" required="required">
                    <span>Full Name</span>

                </div>

                <div class="inputbox">
                    <input type="email" name="" required="required">
                    <span>Email</span>
                    
                </div>

                <div class="inputbox">
                    <textarea required="required"></textarea>
                    <span>Type your Message</span>
                    
                </div>

                <div class="inputbox">
                    <input type="submit" value="Send">
                    
                    
                </div>
            </form>
        </div>
            
    </div>
</section>





<script>
    var swiper = new Swiper(".swiper-container2", {
        slidesPerView: 3.0,
        spaceBetween: 30,
        centeredSlides: true,
        loop: true,
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
    });
</script>

    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    
    <script src="wow.js"></script>

    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <script>
        function toggleMenu() {
            var menu = document.getElementById("menu");
            menu.classList.toggle("show");
        }

        function toggleTheme() {
            let body = document.body;
            let currentTheme = body.classList.contains('dark-theme') ? 'dark' : 'light';
            let newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            
            body.classList.remove(`${currentTheme}-theme`);
            body.classList.add(`${newTheme}-theme`);
            
            localStorage.setItem('theme', newTheme);
        }
        
        // Apply saved theme on page load
        (function () {
            let savedTheme = localStorage.getItem('theme') || 'light';
            document.body.classList.add(`${savedTheme}-theme`);
        })();
    </script>

    <a href="logout.php">Logout</a>


    
</body>
</html>

